<?php
namespace Drupal\demo_module\Controller;

class DemoModuleController {
	
	public function loadPage() {
		
		return [
			'#markup' => 'This is demo module.'
		];
	}
	
	public function secondPage() {
		return [
			#'#markup' => 'This is demo module secondPage.'
			
			'#type' => 'markup',
			'#theme' => 'second_page_template',
			'#content' => $this->loadSecondPageContent(),
			'#myname' => 'Ashwin',
			'#cache' => ['max-age' => 0]
			
		];
	}
	
	private function loadSecondPageContent() {
		return [
			['name' => 'Nilesh', 'Gender' => 'M'],
			['name' => 'Sujaya', 'Gender' => 'F'],
			['name' => 'Prachi', 'Gender' => 'F'],
			['name' => 'Sumit', 'Gender' => 'M'],
			['name' => 'Ashwin', 'Gender' => 'M'],
			['name' => 'Niravsaheb', 'Gender' => 'M'],
		];
	}
	
}